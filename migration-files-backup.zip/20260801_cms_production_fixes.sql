-- CMS Production Fixes - Add missing columns and fix schema issues
-- This migration adds columns required by the CMS application code
-- that were missing from the schema.

-- Add created_by column to blogs table (referenced in entity routes)
alter table if exists public.blogs
  add column if not exists created_by uuid references auth.users(id) on delete set null;

-- Add created_by index for performance
create index if not exists idx_blogs_created_by on public.blogs(created_by);

-- Add created_by column to pages table (for consistency)
alter table if exists public.pages
  add column if not exists created_by uuid references auth.users(id) on delete set null;

create index if not exists idx_pages_created_by on public.pages(created_by);

-- Add created_by column to location_pages table
alter table if exists public.location_pages
  add column if not exists created_by uuid references auth.users(id) on delete set null;

-- Add created_by column to other CMS tables that may need it
alter table if exists public.reusable_sections
  add column if not exists created_by uuid references auth.users(id) on delete set null;

alter table if exists public.page_templates
  add column if not exists created_by uuid references auth.users(id) on delete set null;

alter table if exists public.city_pages
  add column if not exists created_by uuid references auth.users(id) on delete set null;

alter table if exists public.courses
  add column if not exists created_by uuid references auth.users(id) on delete set null;

alter table if exists public.tools_extended
  add column if not exists created_by uuid references auth.users(id) on delete set null;

-- Ensure updated_at trigger exists on blogs
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- Add blogs updated_at trigger if not exists
do $$
begin
  if to_regclass('public.blogs') is not null then
    if not exists (select 1 from pg_trigger where tgname = 'set_blogs_updated_at') then
      create trigger set_blogs_updated_at
      before update on public.blogs
      for each row execute function public.set_updated_at();
    end if;
  end if;
end;
$$;

-- Ensure all CMS tables have proper RLS policies for public reads
do $$
begin
  -- Pages - public read only published
  if to_regclass('public.pages') is not null then
    alter table public.pages enable row level security;
    drop policy if exists "pages_public_select" on public.pages;
    create policy "pages_public_select"
    on public.pages for select
    to anon, authenticated
    using (
      status = 'published'
      and deleted_at is null
      and (published_at is null or published_at <= now())
      and (scheduled_publish_at is null or scheduled_publish_at <= now())
      and (scheduled_unpublish_at is null or scheduled_unpublish_at > now())
    );
  end if;

  -- Blogs - public read only published
  if to_regclass('public.blogs') is not null then
    alter table public.blogs enable row level security;
    drop policy if exists "blogs_public_select" on public.blogs;
    create policy "blogs_public_select"
    on public.blogs for select
    to anon, authenticated
    using (
      status = 'published'
      and deleted_at is null
      and published_at is not null
      and published_at <= now()
      and (scheduled_publish_at is null or scheduled_publish_at <= now())
      and (scheduled_unpublish_at is null or scheduled_unpublish_at > now())
    );
  end if;
end;
$$;

-- Grant proper permissions
grant usage on schema public to anon, authenticated, service_role;
grant select on all tables in schema public to anon;
grant select, insert, update, delete on all tables in schema public to authenticated;
grant all privileges on all tables in schema public to service_role;

do $$
begin
  raise notice 'Applied CMS production fixes migration.';
end;
$$;
